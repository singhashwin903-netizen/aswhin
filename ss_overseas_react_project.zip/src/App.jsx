export default function App() {
  return (
    <div style={{
      minHeight: '100vh',
      background: '#000',
      color: 'white',
      fontFamily: 'Arial',
      padding: '40px'
    }}>
      <h1 style={{color:'#facc15'}}>SS Overseas</h1>
      <h2>Your Dream To Study Abroad Starts Here</h2>

      <p>
        SS Overseas provides complete overseas education support including
        university admissions, SOP assistance, visa guidance and interview preparation.
      </p>

      <h3 style={{color:'#facc15'}}>Services</h3>
      <ul>
        <li>Study Abroad Counselling</li>
        <li>University Applications</li>
        <li>Visa Assistance</li>
        <li>SOP Assistance</li>
        <li>Interview Preparation</li>
      </ul>

      <h3 style={{color:'#facc15'}}>Study Destinations</h3>
      <ul>
        <li>USA</li>
        <li>UK</li>
        <li>Australia</li>
        <li>Europe</li>
      </ul>

      <h3 style={{color:'#facc15'}}>Contact</h3>
      <p>Phone: +91 90523 98859</p>
      <p>Email: swetha.asstmanager2022@gmail.com</p>
      <p>Location: Hyderabad, India</p>
    </div>
  )
}
